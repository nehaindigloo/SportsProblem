package com.glo;

class Soccer extends Sports {
    String getName() {
        return "Soccer Class";
    }

    void getNumberOfTeamMembers() {
        System.out.println("Each team has 11 players in " + getName());
    }
}
